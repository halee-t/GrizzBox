public class Vote {
}
