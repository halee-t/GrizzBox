public class User {
    private String username;
    private int avatarID;
    private int score;

    public User(String username, int avatarID, int score) {
        this.username = username;
        this.avatarID = avatarID;
        this.score = score;
    }
    
}
